package com.touchnav.app;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

public class NavService extends AccessibilityService {
    private static NavService instance;
    @Override public void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { instance = null; }
    public static boolean isRunning() { return instance != null; }
    public static void doBack() { if (instance != null) instance.performGlobalAction(GLOBAL_ACTION_BACK); }
    public static void doHome() { if (instance != null) instance.performGlobalAction(GLOBAL_ACTION_HOME); }
    public static void doRecents() { if (instance != null) instance.performGlobalAction(GLOBAL_ACTION_RECENTS); }
    public static void doNotifications() { if (instance != null) instance.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); }
}
