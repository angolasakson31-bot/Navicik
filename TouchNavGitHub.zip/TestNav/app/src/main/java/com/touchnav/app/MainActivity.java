package com.touchnav.app;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import java.util.List;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btn_overlay).setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));

        findViewById(R.id.btn_access).setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            Toast.makeText(this, "TouchNav Navigasyon'u bulup açın", Toast.LENGTH_LONG).show();
        });

        findViewById(R.id.btn_start).setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Overlay iznini verin!", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent i = new Intent(this, FloatingService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            Toast.makeText(this, "Başlatıldı!", Toast.LENGTH_SHORT).show();
            updateStatus();
        });
    }

    @Override protected void onResume() { super.onResume(); updateStatus(); }

    private void updateStatus() {
        TextView tv = findViewById(R.id.tv_status);
        boolean overlay = Settings.canDrawOverlays(this);
        boolean access = isAccessEnabled();
        tv.setText((overlay ? "✓" : "✗") + " Overlay  " + (access ? "✓" : "✗") + " Erişilebilirlik");
    }

    private boolean isAccessEnabled() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);
        if (am == null) return false;
        List<AccessibilityServiceInfo> list = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo i : list)
            if (i.getId().contains(getPackageName())) return true;
        return false;
    }
}
